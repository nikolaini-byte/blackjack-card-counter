Blackjack Card Counter - Portable Version
======================================

To start the application, run 'BlackjackCardCounter.bat'.

This is a portable version that doesn't require installation.

System Requirements:
- Windows 10 or later
- No additional software required

For support, please visit the project's GitHub page.
